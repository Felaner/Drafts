module.exports = {
    BASE_URL: 'https://чертежи.su',
    HOST: 'localhost',
    DATABASE_USER: 'root',
    DATABASE_PASS: 'VvR%wKDFa~VgZ0J',
    DATABASE_NAME: 'drafts',
    EMAIL_USER: 'kirill.deykun1@gmail.com',
    EMAIL_PASS: 'Leonardo2801',
    EMAIL_HOST: 'smtp.gmail.com'
}