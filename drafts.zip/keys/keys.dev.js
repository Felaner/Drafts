module.exports = {
    BASE_URL: 'https://чертежи.su',
    HOST: 'localhost',
    DATABASE_USER: 'root',
    DATABASE_PASS: 'P3jdmVrbWWnH5K*pA0lL',
    DATABASE_NAME: 'drafts',
    EMAIL_USER: 'kirill.deykun1@gmail.com',
    EMAIL_PASS: 'Leonardo2801',
    EMAIL_HOST: 'smtp.gmail.com'
}